import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, CheckCircle, Star } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <span className="inline-block font-bold">ACME</span>
            </Link>
            <nav className="hidden gap-6 md:flex">
              <Link
                href="#features"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                Features
              </Link>
              <Link
                href="#testimonials"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                Testimonials
              </Link>
              <Link
                href="#pricing"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                Pricing
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <nav className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                Log in
              </Button>
              <Button size="sm">Sign up</Button>
            </nav>
          </div>
        </div>
      </header>

      
    <main className="flex-1 flex flex-col items-center justify-center text-center p-4 bg-gradient-to-br from-purple-700 via-pink-500 to-yellow-400 animate-gradient">
      <h1 className="text-6xl font-extrabold text-white mb-4 animate-bounce" style={{ textShadow: "0 0 10px #fff, 0 0 20px #f0f, 0 0 30px #0ff" }}>
        Divyanshu Bairwa
      </h1>
      <p className="text-xl text-white mb-2">College Student - Jaipur University</p>
      <p className="text-xl text-white mb-2">Website Developer</p>
      <p className="text-xl text-white mb-2">Professional Hacker</p>
      <p className="text-md text-white mb-2">Email: <a href="mailto:dkb99113@gmail.com" className="underline">dkb99113@gmail.com</a></p>
      <p className="text-md text-white mb-6">Phone: 7733874780</p>
      <section className="max-w-2xl text-white text-lg bg-black bg-opacity-40 p-4 rounded-xl shadow-lg animate-fade-in">
        <h2 className="text-2xl font-semibold mb-2">About Me</h2>
        <p>
          I’m Divyanshu Bairwa, a passionate college student from Jaipur University. I specialize in modern web development, blending creativity with cutting-edge tech.
          My interests range from ethical hacking to full-stack development. With a strong learning mindset and problem-solving skills, I strive to create powerful digital experiences.
        </p>
      </section>
    </main>


      {/* Footer */}
      <footer className="w-full border-t bg-background py-6">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
            <div className="space-y-3">
              <h4 className="text-base font-medium">Company</h4>
              <nav className="flex flex-col space-y-2">
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  About
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Careers
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Press
                </Link>
              </nav>
            </div>
            <div className="space-y-3">
              <h4 className="text-base font-medium">Product</h4>
              <nav className="flex flex-col space-y-2">
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Features
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Pricing
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Integrations
                </Link>
              </nav>
            </div>
            <div className="space-y-3">
              <h4 className="text-base font-medium">Resources</h4>
              <nav className="flex flex-col space-y-2">
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Documentation
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Guides
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Support
                </Link>
              </nav>
            </div>
            <div className="space-y-3">
              <h4 className="text-base font-medium">Legal</h4>
              <nav className="flex flex-col space-y-2">
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Privacy
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Terms
                </Link>
                <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                  Cookie Policy
                </Link>
              </nav>
            </div>
          </div>
          <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t pt-6 md:h-24 md:flex-row">
            <p className="text-center text-sm text-muted-foreground md:text-left">
              © {new Date().getFullYear()} ACME Inc. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">Twitter</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">GitHub</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path>
                  <path d="M9 18c-4.51 2-5-2-7-2"></path>
                </svg>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground">
                <span className="sr-only">LinkedIn</span>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                  <rect width="4" height="12" x="2" y="9"></rect>
                  <circle cx="4" cy="4" r="2"></circle>
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

// Sample data
const features = [
  {
    icon: CheckCircle,
    title: "Easy Integration",
    description: "Seamlessly integrate with your existing systems and workflows.",
  },
  {
    icon: CheckCircle,
    title: "Powerful Analytics",
    description: "Gain valuable insights with our advanced analytics dashboard.",
  },
  {
    icon: CheckCircle,
    title: "Secure Platform",
    description: "Enterprise-grade security to keep your data safe and protected.",
  },
]

const testimonials = [
  {
    content: "This platform has completely transformed how we operate. The efficiency gains have been remarkable.",
    name: "Sarah Johnson",
    title: "CEO, TechCorp",
    rating: 5,
  },
  {
    content: "The customer support is outstanding. They're always available to help with any questions.",
    name: "Michael Chen",
    title: "CTO, Innovate Inc",
    rating: 5,
  },
  {
    content: "We've seen a 40% increase in productivity since implementing this solution.",
    name: "Emily Rodriguez",
    title: "Operations Manager, GrowthCo",
    rating: 4,
  },
]

const pricingPlans = [
  {
    name: "Starter",
    description: "Perfect for small businesses",
    price: 29,
    features: ["Up to 5 users", "Basic analytics", "24/7 support", "1GB storage"],
  },
  {
    name: "Professional",
    description: "Ideal for growing teams",
    price: 79,
    featured: true,
    features: ["Up to 20 users", "Advanced analytics", "24/7 priority support", "10GB storage", "Custom integrations"],
  },
  {
    name: "Enterprise",
    description: "For large organizations",
    price: 199,
    features: [
      "Unlimited users",
      "Premium analytics",
      "24/7 dedicated support",
      "Unlimited storage",
      "Custom integrations",
      "Dedicated account manager",
    ],
  },
]
